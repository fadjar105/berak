    <div class="container">

        <div class="row">
            <!-- Blog Sidebar Widgets Column -->
            <div class="col-md-4">

                <!-- Blog Categories Well -->
                <div class="well">
                    <h4>Admin Menu</h4>
                    <div class="row">
                        <div class="col-lg-6">
                            <ul class="nav nav-pills nav-stacked">
                                <li><a href="<?=base_url('front/tambah_artikel');?>">Tambah Artikel</a></li>
                                <li><a href="<?=base_url('front/daftar_artikel');?>">Daftar Artikel</a></li>
								<li><a href="<?=base_url('front/daftar_testimoni');?>">Daftar Testimoni</a></li>								
								<li><a href="<?=base_url();?>">Lihat Website</a></li>
								<li><a href="<?=base_url('user/logout');?>">Logout</a></li>
                            </ul>
                        </div>
                        <!-- /.col-lg-6 -->

                    </div>
                    <!-- /.row -->
                </div>


            </div>


        <!-- /.row -->
	<!-- /.container -->