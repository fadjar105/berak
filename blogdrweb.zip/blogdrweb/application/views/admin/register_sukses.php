<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
	<head>
	<meta charset="utf-8">	
	<title>Register Sukses</title>
	<style type="text/css">
		
	</style>
	</head>
	<body>
		<h1>Registrasi Member Sukses</h1>
		<p>Selamat bergabung ... </p>
		
	</body>
</html>