<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="en">
	<head>
	<meta charset="utf-8">	
	<title>Category Page!</title>
	</head>
	<body>
		<h1>Anda sedang mengakses halaman 'category'</h1>
	</body>

</html>