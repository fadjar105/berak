-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 14, 2016 at 07:43 AM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `zero`
--

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `comment_id` int(4) NOT NULL AUTO_INCREMENT,
  `comment_name` varchar(255) NOT NULL,
  `comment_email` varchar(255) NOT NULL,
  `comment_body` text NOT NULL,
  `comment_date` date NOT NULL,
  `ID` int(11) NOT NULL,
  PRIMARY KEY (`comment_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`comment_id`, `comment_name`, `comment_email`, `comment_body`, `comment_date`, `ID`) VALUES
(2, 'nanda', 'nanda@gmail.com', 'asdfasdfasdfasdf', '2016-11-24', 31),
(3, 'hafizh', 'hafizh@gmail.com', 'asdfasdfasdf', '2016-11-24', 28),
(4, 'ali', 'ali@gmail.com', 'asdfadsfadsf', '2016-11-24', 31),
(5, 'asdfasdfasdfasdfa', 'sadfasdfasdf@asdfasdf.com', 'asdfasdfas asdfasdfasd', '2016-11-24', 31),
(6, 'ari', 'ari@gmail.com', 'test koment ya', '2016-11-25', 25);

-- --------------------------------------------------------

--
-- Table structure for table `lagu`
--

CREATE TABLE IF NOT EXISTS `lagu` (
  `id_lagu` int(5) NOT NULL AUTO_INCREMENT,
  `judul` varchar(200) NOT NULL,
  `penyanyi` varchar(200) NOT NULL,
  PRIMARY KEY (`id_lagu`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_post`
--

CREATE TABLE IF NOT EXISTS `tbl_post` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `author` varchar(75) NOT NULL,
  `date` date NOT NULL,
  `content` text NOT NULL,
  `featured_image` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `tbl_post`
--

INSERT INTO `tbl_post` (`ID`, `title`, `author`, `date`, `content`, `featured_image`) VALUES
(11, 'Cara Install Plugin', 'Hafizh', '2016-11-12', 'Di Blog DokterWeb banyak membahas mengenai plugin yang bermanfaat untuk website anda tapi beberapa pengunjung menanyakan cara menginstall plugin pada wordpress. Maka pada artikel ini saya akan membahas buat anda yang baru belajar membuat website dengan wordpress cara menginstall plugin.', 'http://localhost/zero/project14/uploads/purple3.jpg'),
(12, 'Cara buat Accordian Slide', 'Aqila', '2016-11-12', 'Pada tutorial kali ini saya ingin memberikan informasi bagaimana agar website anda cantik dan atraktif dengan tampilan slide accordian. Slide accordian ini cocok bagi website berita, blog pribadi bahkan website company profile sekelas perusahaan sekaligus. Karena selain menghemat tempat juga informasi  yang disampaikan kepada pembaca jelas.', 'http://localhost/zero/project14/uploads/gray1.jpg'),
(13, 'Cara Menambahkan Like Reaksi di Wordpress', 'DokterWeb', '2016-11-12', 'Komentar pengunjung di blog anda sangat menyenangkan bukan, tapi buat blog atau artikel anda lebih menarik dengan tombol Reaksi. Tombol Reaksi emosional mengundang reaksi dari pengunjung anda dimana memberikan umpan balik yang cepat di artikel yang anda buat. ', 'http://localhost/zero/project14/uploads/tosca2.jpg'),
(14, 'Cara Mudah Membuat Fixed Widget di Wordpress', 'Hafizh', '2016-11-12', 'Oke, pada artikel kali ini saya akan membahas cara mudah membuat fixed widget di wordpress agar website anda lebih menjual. Kenapa saya bilang menjual, karena fungsi fixed widget biasanya untuk promo suatu produk, dengan tampilan yang mengambang tetap terlihat sekalipun user scroll web anda ke bagian paling bawah.', 'http://localhost/zero/project14/uploads/red9.jpg'),
(15, 'Cegah Copy Paste', 'Lia', '2016-11-12', 'Anda mungkin pernah menjadi korban pic, maupun artikel dari website anda di copy dan jadikan artikel di website orang lain. Tentu hal itu sangat menganggu, karena susah payah anda membuat gambar yang di disain bagus ataupun susah payah anda membuat artikel yang bagus tetapi anda menemukan gambar maupun artikel anda di website orang lain. Yang artinya orang lain mengcopy hasil karya anda.', 'http://localhost/zero/project14/uploads/purple2.jpg'),
(16, 'Menambah Back to Top', 'DokterWeb', '2016-11-12', 'Ketika website ataupun blog anda sudah memiliki banyak artikel, fasilitas back to top mesti anda pasang agar memudahkan pengunjung . Back to top yang artinya "Kembali ke atas" adalah fasilitas ketika di klik tombol tersebut secara otomatis akan scroll ke atas. ', 'http://localhost/zero/project14/uploads/green.jpg'),
(17, 'Membuat Excerpt', 'Aqila', '2016-11-12', 'Sebelum membahas kegunaan excerpt sebaiknya kita mengetahui apa itu excerpt?\r\nExcerpt adalah fasilitas yang diberikan oleh wordpress untuk memberikan cuplikan suatu artikel agar sebuah blog tidak dipenuhi secara full dari masing-masing artikel. Dari desain menarik dan dari kemudahan pembaca juga enak agar pembaca tidak scroll blog anda sampai kebawah sehingga pembaca cukup membaca summary artikel anda saja.\r\n', 'http://localhost/zero/project14/uploads/gray.jpg'),
(18, 'Highlight Comment', 'Lia', '2016-11-12', 'Artikel yang bagus tentu banyak di sukai oleh pembaca, apalagi artikel anda di komen oleh pengunjung blog, tentu sangat menyenangkan. Jika artikel ini terkait ilmu dan sangat anda perlukan sudah pasti akan baca sampai ke komentar nya, dan yang paling anda cari pasti komentar si pemiliik blog tersebut, karena biasanya pemilik webnya lah yang mempunyai ilmu yang anda perlukan.', 'http://localhost/zero/project14/uploads/blue1.jpg'),
(19, 'Highlight Comment 02', 'Lia', '2016-11-12', 'Jika komen pembaca anda masih sedikit tentu mudah pembaca lain membaca komenter blog anda, namun jika komentar sudah banyak tentu pembaca juga repot menganalisa komentar tersebut. Sebagai pemilik website atau blog anda harus membuat gimana caranya agar komentar kita mudah di temukan.  Salah satu caranya adalah memberikan highlight warna di komentar pemilik website seperti pic di atas', 'http://localhost/zero/project14/uploads/yellow1.jpg'),
(20, 'Membuat Image Gallery ', 'DokterWeb', '2016-11-12', 'Bagi anda pengguna Blogger, slideshow bisa anda temukan di gadget, tetapi gimana caranya agar slideshow bisa anda terapkan di halaman?\r\nSalah satu fungsi slideshow sebagai image gallery, tentu dengan animasi yang ringan membuat website maupun blog anda tampil cantik.  Silahkan anda lihat demo dibawah\r\n', 'http://localhost/zero/project14/uploads/tosca1.jpg'),
(21, 'Bekerja Tanpa Target', 'Aqila', '2016-11-12', 'Kalau bicara dunia kerja pasti bicara target, apalagi team sales sudah tentu punya target penjualan di perusahaan mereka masing-masing. Baik itu target mingguan, bulanan dan tahunan. \r\nLalu apakah target hanya diterapkan di dunia kerja saja? Jawabannya tentu tidak.  Target itu dikenakan di semua kalangan baik anak-anak, remaja, dewasa mapun yang sudah tua. Contoh target nya seperti:\r\n', 'http://localhost/zero/project14/uploads/red8.jpg'),
(22, 'Membuat Mini Studio Sederhana', 'DokterWeb', '2016-11-12', 'Dengan fasilitas internet yang murah dan gadget yang terjangkau membuat Online shop semakin menjamur di Indonesia. Karena jualan online sangat murah dan mudah, apalagi smartphone juga rata-rata sudah memiliki fitur kamera.  ', 'http://localhost/zero/project14/uploads/purple1.jpg'),
(23, 'Mini Studio 2', 'Lia', '2016-11-12', 'Apapun media yang anda gunakan untuk berjualan baik itu social media, market place, atau toko online anda sendiri, salah satu trik untuk menarik pembeli adalah foto produk yang bagus. Calon pembeli pasti akan tertarik dengan foto yang enak dilihat, baik dari sisi pencahayaan, angle, jarak foto dan lainnya. Anda tidak perlu menggunakan DSLR karena dengan kamera smartphone andapun juga bisa menghasilkan foto produk yang baik dan enak dilihat.', 'http://localhost/zero/project14/uploads/blue.jpg'),
(24, 'theme', 'drweb', '2016-11-12', 'Oke, pada artikel kali ini saya akan membahas cara mudah membuat fixed widget di wordpress agar website anda lebih menjual. Kenapa saya bilang menjual, karena fungsi fixed widget biasanya untuk promo suatu produk, dengan tampilan yang mengambang tetap terlihat sekalipun user scroll web anda ke bagian paling bawa', 'http://localhost/zero/project14/uploads/purple.jpg'),
(25, 'test BS2 edit', 'drweb', '2016-11-12', 'Di Blog DokterWeb banyak membahas mengenai plugin yang bermanfaat untuk website anda tapi beberapa pengunjung menanyakan cara menginstall plugin pada wordpress. Maka pada artikel ini saya akan membahas buat anda yang baru belajar membuat website dengan wordpress cara menginstall plugin.', 'http://localhost/zero/project14/uploads/yellow.jpg'),
(28, 'project 09 test1 edit', 'drweb edit', '2016-11-12', 'Pada tutorial kali ini saya ingin memberikan informasi bagaimana agar website anda cantik dan atraktif dengan tampilan slide accordian. Slide accordian ini cocok bagi website berita, blog pribadi bahkan website company profile sekelas perusahaan sekaligus. Karena selain menghemat tempat juga informasi  yang disampaikan kepada pembaca jelas.', 'http://localhost/zero/project14/uploads/tosca.jpg'),
(29, 'segment test project 10', 'drweb', '2016-11-12', 'Komentar pengunjung di blog anda sangat menyenangkan bukan, tapi buat blog atau artikel anda lebih menarik dengan tombol Reaksi. Tombol Reaksi emosional mengundang reaksi dari pengunjung anda dimana memberikan umpan balik yang cepat di artikel yang anda buat. asdfasdfadsf', 'http://localhost/zero/project14/uploads/red10.jpg'),
(31, 'bootstrap', 'drweb', '2016-12-13', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna. Nunc viverra imperdiet enim. Fusce est. Vivamus Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas porttitor congue massa. Fusce posuere, magna sed pulvinar ultricies, purus lectus malesuada libero, sit amet commodo magna eros quis urna. Nunc viverra imperdiet enim. Fusce est. Vivamus a tellus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Proin pharetra nonummy pede. Mauris et orci. Aenean nec lorem. In porttitor. Donec laoreet nonummy augue. Suspendisse dui purus, scelerisque at, vulputate vitae, pretium mattis, nunc. Mauris eget neque at sem venenatis eleifend. Ut nonummy. Fusce aliquet pede non pede. Suspendisse dapibus lorem pellentesque magna. Integer nulla. Donec blandit feugiat ligula. Donec hendrerit, felis et imperdiet euismod, purus ipsum pretium metus, in lacinia nulla nisl eget sapien. Donec ut est in lectus consequat consequat. Etiam eget dui. Aliquam erat volutpat. Sed at lorem in nunc porta tristique. Proin nec augue. Quisque aliquam tempor magna. Pellentesque habitant morbi tr', 'http://localhost/zero/project15/uploads/gray3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `user_id` int(100) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `active_since` date NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`user_id`, `username`, `password`, `active_since`) VALUES
(1, 'dokterweb', '$2a$12$XlXoiSpqF8zeVejlAu8RLuV90kadN.5mOEIjz5MUFbCLn.Xi/3qVe', '2016-10-27'),
(2, 'admin', '$2a$12$Gsu.d/pNW2ReELGDkKu9BOE5zeYSOQM1VF0lxbpnzaZxQlsTloBTu', '2016-10-30'),
(3, 'hafizh', '$2a$12$97Gj.cs3TvTYbjZK8Hg4c.7U3maEC9XQV9qBQXDqiI2QLpzLwKz1S', '2016-12-10'),
(4, 'aisyah', '$2a$12$/0gVRugqPbvn7GGmzBmFl.b4d9HkEQ1ZclU7CSzKLwQiCCbr7t1ee', '2016-12-10'),
(5, 'abi', '$2a$12$r2oYBFCDNfhpY2hY5uOG6Oi9tdFAWzfqm5PZbLSA3VRn5VrpAug9.', '2016-12-12'),
(6, 'lia', '$2a$12$tOuqNEyyYz1N5CDM.o5ZrOV1Be4tRaz5s0ohbWt7STxcF1AtWBKU6', '2016-12-12');

-- --------------------------------------------------------

--
-- Table structure for table `testi`
--

CREATE TABLE IF NOT EXISTS `testi` (
  `testi_id` int(11) NOT NULL AUTO_INCREMENT,
  `name_testi` varchar(100) NOT NULL,
  `email_testi` varchar(150) NOT NULL,
  `testi` text NOT NULL,
  PRIMARY KEY (`testi_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `testi`
--

INSERT INTO `testi` (`testi_id`, `name_testi`, `email_testi`, `testi`) VALUES
(2, 'lia', 'lia@lia.com', 'coba dulu testi nya ya'),
(3, 'hafizh', 'hafizh@hafizh.com', 'test ya bi'),
(5, 'aqila', 'aqila@gmail.com', 'apa kabar abi, semoga sukses'),
(6, 'aqila', 'aqila@gmail.com', 'apa kabar abi, semoga sukses'),
(7, 'amin', 'amin@amin.com', 'bismillah'),
(8, 'siti', 'siti@yahoo.com', 'bismillah ajaya');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
